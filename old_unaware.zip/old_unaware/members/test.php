<?php

// Connection à la base de données;
// --------------------------------------------------------------------------------------------------------------------
try
{
	$base_de_donnees = new PDO('mysql:host=localhost;dbname=unaware;charset=utf8', 'root', '');
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}

$reponse = $base_de_donnees->query('SELECT * FROM membres');

$const = true;
$var = false;
while ($données = $reponse->fetch())
{
	echo $données['pseudo'] . '	';

	if ($données['pseudo'] == $_POST['addr_email'])
	{
		$var = true;
	}
}

if ($var AND $const)
{
	echo 'YES !!!';
}

?>