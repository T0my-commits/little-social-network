<?php

$_error = false;
if ( isset($_POST['pseudo']) AND $_POST['password'])
{
	// On vérifie les données de connection;
	// ------------------------------------------------------------------------------------------------------------;

	// On vérifie que tout les champs on été remplis;
	if (! isset($_POST['pseudo']) AND $_POST['password'])
	{
		$_error = true;
	}
	$pseudo = strip_tags($_POST['pseudo']);

	// Connection avec la base de données;
	$bdd = new PDO('mysql:host=localhost;dbname=unaware;charset=utf8', 'root', '');

	// On vérifie que les mots de passe sont bien indentiques;
	//  Récupération de l'utilisateur et de son pass hashé;
	$req = $bdd->prepare('SELECT * FROM members WHERE pseudo = :pseudo');
	$req->execute(array(
	    'pseudo' => $pseudo));
	$resultat = $req->fetch();

	// Comparaison du pass envoyé via le formulaire avec la base;
	$isPasswordCorrect = password_verify($_POST['password'], $resultat['password']);

	if (!$resultat)
	{
	    $_error = true;
	}
	else
	{
	    if ($isPasswordCorrect) {
	        session_start();
			$_SESSION = array(
				'id' => $resultat['id'],
				'firstname' => $firstname,
				'lastname' => $lastname,
				'birthday' => $birthday,
			    'email' => $email,
			    'pseudo' => $pseudo);
	        header('Location: ../index.php');
	    }
	    else {
	        $_error = true;
	    }
	}

	$req->closeCursor();
}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset='utf-8' />
	<title>Unaware - Connection</title>
	<link href='../color/color_purple.css' rel='stylesheet' />
	<link href='../style.css' rel='stylesheet' />
	<style type="text/css">
		body {
			top: 0px;
			bottom: 0px;
			opacity: 1;
		}

		#contact {
			width: 500px;
			padding: 10px 25px;
			border-radius: 100px;
			margin-top: 5%;
			font-family: 'montserratregular';
			display: flex;
			justify-content: space-around;
			align-items: center;
			align-self: center;
			flex-direction: column;
			height: 100px;
			color: white;
			background-color: var(--footer-bg-color);
			text-align: center;
			font-size: 18px;
			word-spacing: normal;
		}

		aside {
			height: 100%;
			justify-content: column;
			padding: 0px;
		}

		form {
			margin: auto;
		}

		.alert
		{
			width: 300px;
			margin: auto;
			padding-bottom: 8px;
			margin-bottom: 0px;
			background-color: rgba(255, 255, 255, 0.7);
		}
	</style>
</head>


<body>
	<aside style='flex-direction: column;'>
		<!-- On affiche un formulaire de connection -->
		<h1 id='contact'>Nous sommes heureux de vous voir ici</h1>

		<?php
		if ($_error)
		{
			 echo "<p class='alert'>Mauvais identifiant ou mot de passe.</p>";
		}
		?>

		<form action='connection.php' method='POST'>

			<label>Votre pseudo<input type='text' name='pseudo' placeholder='Votre pseudo' required autofocus /></label>

			<div style='margin: 15px 0px; border: 1px inset rgba(89, 89, 89, 0.25);'></div>

			<label>Votre mot de passe<input type='password' name='password' placeholder='Votre mot de passe' required /></label>

			<div style='display: flex; justify-content: center;'>
				<input type='submit' value='Soumettre' class='submit' />
			</div>

			<p><a href='#'> Mot de passe oublié ?</a></p>
			<p><a href='../index.php?post'> Pas encore inscrit ?</a></p>

		</form>
	</aside>
</body>
</html>