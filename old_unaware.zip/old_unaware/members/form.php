<?php
$var = 'Coucou mon chou';

$bdd = new PDO('mysql:host=localhost;dbname=unaware;charset=utf8', 'root', '');
$req = $bdd->prepare('SELECT pseudo FROM membres WHERE pseudo = :pseudo');
$req->execute(array(
    'pseudo' => 'Malo'));
$resultat = $req->fetch();

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset='utf-8' />
	<title>Test</title>
</head>

<body>

	<form action='test.php' method='POST'>
		<label>Entrer une adresse email <input type='text' name='addr_email' placeholder='Adresse électronique' autofocus /></label>
		<input type='submit' />
		<p><?php echo $resultat['pseudo']; ?>
	</form>

</body>
</html>