<?php
session_start();

require('main/index_control.php');
require('main/index_model.php');

try
{
	if (isset($_GET['no_js'])){
		$_SESSION['no_js'] = true;
	}

	if (isset($_SESSION['id'])) {
		$opt = "<a href='#'><div class='menu'><img src='pictures/profile_icon.png' /><br />Mon profil</div></a>";
	}
	else {
		$opt = "<a href='#'><div class='menu'><img src='pictures/profile_icon.png' /><br />Options</div></a>";
	}
}
catch(Exception $e)
{
	$e->getMessage();
}

require('main/index_view.php');