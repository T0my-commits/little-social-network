<!DOCTYPE html>
<html>
<head>
	<meta charset='utf-8' />
	<title>Unaware - Acceuil</title>
	<link href='color/color_purple.css' rel='stylesheet' />
	<link href='../style.css' rel='stylesheet' />
	<link href='goodies/style_dock.css' rel='stylesheet' />
	<?php if (isset($_SESSION['no_js'])) { echo "<link href='style_noJs.css' rel='stylesheet' />"; } ?>
</head>

<!-- On défini l'en-tête de notre page -->
<?php include('goodies/dock.php'); ?>

<body>

<!-- Mise en page de la rubrique 'registration' -->
<div class='registration' <?php if (isset($_GET['post']) OR isset($_SESSION['pseudo'])) {echo 'style="display: block;"';} ?>>
	<aside>
		<!-- Showing registration form & interface for user who is connected -->
		<?php include('goodies/registration_form.php'); ?>
	</aside>
</div>

<!-- First block (body website) -->
<div class='first_block'>
	<p>\\ Bienvenue sur Unaware !</p>
	<h1>Découvrez les formations d'aujourd'hui pour mieux apprécier les métiers de demain</h1>
	<div id='hide'>
		<div class='show_trainings'>
			<!-- All -->
			<p><a style='color: var(--main-bg-color);' href='forum/post_control.php'>Toutes les formations</a></p>
			<!-- En Université -->
			<p><a style='color: #39a290;' href='forum/post_control.php?type="Licences et Licences pro"'>Licences et Licences pro</a></p>
			<p><a style='color: #2c6ebe;' href='forum/post_control.php?type="Dentaire"'>Dentaire</a></p>
			<p><a style='color: #2c6ebe;' href='forum/post_control.php?type="Médecine"'>Médecine</a></p>
			<p><a style='color: #2c6ebe;' href='forum/post_control.php?type="Pharmacie"'>Pharmacie</a></p>
			<p><a style='color: #2c6ebe;' href='forum/post_control.php?type="Maïeutique"'>Maïeutique</a></p>
			<p><a style='color: #2c6ebe;' href='forum/post_control.php?type="Kinésithérapie"'>Kinésithérapie</a></p>
			<p><a style='color: #2c6ebe;' href='forum/post_control.php?type="Paramédical"'>Paramédical</a></p>
			<p><a style='color: #a7c619;' href='forum/post_control.php?type="DEUST"'>DEUST</a></p>
			<p><a style='color: #a7c619;' href='forum/post_control.php?type="DUT"'>DUT</a></p>
			<!-- Au lycée -->
			<p><a style='color: #db5d49;' href='forum/post_control.php?type="Design lycee"'>Design (lycée)</a></p>
			<p><a style='color: #e1c232;' href='forum/post_control.php?type="BTS"'>BTS</a></p>
			<!-- Au lycée puis en grande école -->
			<p><a style='color: #66a3d8;' href='forum/post_control.php?type="Prépa sciences"'>Prépa sciences</a></p>
			<p><a style='color: #529296;' href='forum/post_control.php?type="Prépa éco"'>Prépa éco</a></p>
			<p><a style='color: #ce651d;' href='forum/post_control.php?type="Prépa lettres"'>Prépa lettres</a></p>
			<!-- En école -->
			<p><a style='color: #9da06b;' href='forum/post_control.php?type="Grandes écoles post bac"'>Grandes écoles post bac (Ingénieurs, commerce, arts...)</a></p>
			<p><a style='color: #9da06b;' href='forum/post_control.php?type="Institut détudes politiques"'>Institut d'études politiques</a></p>
			<p><a style='color: #5a989b;' href='forum/post_control.php?type="Comptabilité"'>Comptabilité</a></p>
			<p><a style='color: #b17a16;' href='forum/post_control.php?type="Social"'>Social</a></p>
			<p><a style='color: #738bc7;' href='forum/post_control.php?type="Paramédical"'>Paramédical</a></p>
			<p><a style='color: #db5d49;' href='forum/post_control.php?type="Design ecole"'>Design (école)</a></p>
			<p><a style='color: #d54955;' href='forum/post_control.php?type="Beaux-Arts"'>Beaux-Arts</a></p>
			<p><a style='color: #ec7435;' href='forum/post_control.php?type="Architecture"'>Architecture</a></p>
			<p><a style='color: #b8978a;' href='forum/post_control.php?type="Autres écoles"'>Autres écoles (vente, industrie, tourisme, transports, communication...)</a></p>
		</div>
	</div>
	<p id='discover_sectors' class='dev_areas'><a>Je découvre les formations !</a></p>
</div>

<!-- Second block (body website) -->
<div class='second_block'>
	<h1>\\ Racontez-nous votre histoire</h1>
	<p>Rencontrez des lycéens soucieux des conditions de vie dans le supérieur, des motivations qui poussent à suivre une formation et de
	vos annecdotes personnelles. N'hésitez pas, venez nous raconter votre histoire !</p>
</div>

<div id='members_interface'>
	<!-- members icons (body website) -->
	<div class='my_profile'>
		<a>
			<img src='pictures/profil.jpeg' alt='Mon profil' />
			<h5>Mon profil</h5>
			<p>Completez votre profil, renseignez le type de votre formation, vos centres d'intérets et vos informations personnelles - que vous souhaitez partager -
			pour assurer une meilleur expérience sur Unaware.</p>
		</a>
	</div>
	<div class='my_conversations'>
		<a>
			<img src='pictures/conversations.jpg' alt='Mes conversations' />
			<h5>Mes conversations</h5>
			<p>Découvrez - et re-découvrez - vos conversations en cours. Partagez votre expérience, posez des questions et aidez d'autres
			personnes à trouver leur orientation de manière optimisée !</p>
		</a>
	</div>
	<div class='dicovery'>
		<a>
			<img src='pictures/dicovery.jpg' alt='Découvrir les discussions' />
			<h5>Découvrir les discussions</h5>
			<p>Explorez les différents posts ouverts et participez à leur flux d'informations gratuitement. Posez des questions, répondez
			à d'autres personnes et bouquinez ce qui s'est déjà partagé sur la platforme ! Enjoy ;)</p>
		</a>
	</div>
	
</div>

<!-- Showing footer -->
<?php include('goodies/footer.php'); ?>

<!-- Loading file .js -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src='main/anim.js' type='text/javascript'></script>

</body>
</html>