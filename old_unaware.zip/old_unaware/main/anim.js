/*$(function() {
	$('#site').animate({
		top: '80px',
		opacity: '1'
	}, 880);
});*/
$(function() {
	$('body').css('top', '300px').css('opacity', '0').animate({
		top: '80px',
		opacity: '1'
	}, 880);
	$('#alea').css('display', 'none');
});

$('.menu').on('click', function() {
	$('#options_menu').slideToggle(150).css('display', 'block');
	$(this).toggle(150).toggle(150);
});

$('a:not(.menu)').on('click', function() {
	$(this).slideUp(150).slideDown(150);
});

$('.inscript').on('click', function() {
	$('.registration').slideToggle(600);
});

$('.dev_areas').on('click', function() {
	$('#hide').slideToggle(300).css('display', 'block');
});

$('.research').on('click', function() {
	$('#research').slideToggle(300).css('display', 'block');
});