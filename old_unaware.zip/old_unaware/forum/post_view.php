<!DOCTYPE html>
<html>
<head>
	<meta charset='utf-8' />
	<title>Unaware - Secteurs d'activité</title>
	<link href='../color/color_purple.css' rel='stylesheet' />
	<link href='../goodies/style_dock.css' rel='stylesheet' />
	<link href='forum_sheet.css' rel='stylesheet' />
</head>

<!-- Barre de menu principale -->
<?php include('../goodies/dock.php'); ?>

<body>

<!-- ======================== Making block research ======================== -->
<div id='research'>
	<div id='menu_research'>
		<!-- En Université -->
		<div class='universite'>
			<h1>\\ Universités</h1>
			<p><a style='color: #39a290; border-bottom: 1px solid #39a290 ;' href='post_control.php?type="Licences et Licences pro"'>\\ Licences et Licences pro</a></p>
			<p><a style='color: #2c6ebe; border-bottom: 1px solid #2c6ebe ;' href='post_control.php?type="Dentaire"'>\\ Dentaire</a></p>
			<p><a style='color: #2c6ebe; border-bottom: 1px solid #2c6ebe ;' href='post_control.php?type="Médecine"'>\\ Médecine</a></p>
			<p><a style='color: #2c6ebe; border-bottom: 1px solid #2c6ebe ;' href='post_control.php?type="Pharmacie"'>\\ Pharmacie</a></p>
			<p><a style='color: #2c6ebe; border-bottom: 1px solid #2c6ebe ;' href='post_control.php?type="Maïeutique"'>\\ Maïeutique</a></p>
			<p><a style='color: #2c6ebe; border-bottom: 1px solid #2c6ebe ;' href='post_control.php?type="Kinésithérapie"'>\\ Kinésithérapie</a></p>
			<p><a style='color: #2c6ebe; border-bottom: 1px solid #2c6ebe ;' href='post_control.php?type="Paramédical"'>\\ Paramédical</a></p>
			<p><a style='color: #a7c619; border-bottom: 1px solid #a7c619 ;' href='post_control.php?type="DEUST"'>\\ DEUST</a></p>
			<p><a style='color: #a7c619; border-bottom: 1px solid #a7c619 ;' href='post_control.php?type="DUT"'>\\ DUT</a></p>
		</div>
		<!-- Au lycée -->
		<div class='lycee'>
			<h1>\\ Lycées</h1>
			<p><a style='color: #db5d49; border-bottom: 1px solid #db5d49 ;' href='post_control.php?type="Design lycee"'>\\ Design (lycée)</a></p>
			<p><a style='color: #e1c232; border-bottom: 1px solid #e1c232 ;' href='post_control.php?type="BTS"'>\\ BTS</a></p>
		</div>
		<!-- Au lycée puis en grande école -->
		<div class='lycee_gd_ecoles'>
			<h1>\\ Lycées & Grandes Ecoles</h1>
			<p><a style='color: #66a3d8; border-bottom: 1px solid #66a3d8 ;' href='post_control.php?type="Prépa sciences"'>\\ Prépa sciences</a></p>
			<p><a style='color: #529296; border-bottom: 1px solid #529296 ;' href='post_control.php?type="Prépa éco"'>\\ Prépa éco</a></p>
			<p><a style='color: #ce651d; border-bottom: 1px solid #ce651d ;' href='post_control.php?type="Prépa lettres"'>\\ Prépa lettres</a></p>
		</div>
		<!-- En école -->
		<div class='ecoles'>
			<h1>\\ Ecoles</h1>
			<p><a style='color: #9da06b; border-bottom: 1px solid #9da06b ;' href='post_control.php?type="Grandes écoles post bac"'>\\ Grandes écoles post bac (Ingénieurs, commerce, arts...)</a></p>
			<p><a style='color: #9da06b; border-bottom: 1px solid #9da06b ;' href='post_control.php?type="Institut détudes politiques"'>\\ Institut d'études politiques</a></p>
			<p><a style='color: #5a989b; border-bottom: 1px solid #5a989b ;' href='post_control.php?type="Comptabilité"'>\\ Comptabilité</a></p>
			<p><a style='color: #b17a16; border-bottom: 1px solid #b17a16 ;' href='post_control.php?type="Social"'>\\ Social</a></p>
			<p><a style='color: #738bc7; border-bottom: 1px solid #738bc7 ;' href='post_control.php?type="Paramédical"'>\\ Paramédical</a></p>
			<p><a style='color: #db5d49; border-bottom: 1px solid #db5d49 ;' href='post_control.php?type="Design ecole"'>\\ Design (école)</a></p>
			<p><a style='color: #d54955; border-bottom: 1px solid #d54955 ;' href='post_control.php?type="Beaux-Arts"'>\\ Beaux-Arts</a></p>
			<p><a style='color: #ec7435; border-bottom: 1px solid #ec7435 ;' href='post_control.php?type="Architecture"'>\\ Architecture</a></p>
			<p><a style='color: #b8978a; border-bottom: 1px solid #b8978a ;' href='post_control.php?type="Autres écoles"'>\\ Autres écoles (vente, industrie, tourisme, transports, communication...)</a></p>
		</div>
	</div>
</div>


<!-- ======================== Making conversations ======================== -->
<?php
// We're showing all chats that are selected;
while ($data = $answers->fetch()) { ?>


<!-- A dialog box -->
<div class='set_of'>
	<div class='box'>
		<img src='../pictures/session_icons/purple_gamepad.png' rel="Icone de session du membre" />
		<div>
			<h2><a href='<?= "chat_control.php?threat=" . $data['ID_FORUM']; ?>'><?php echo $data['titre'] ?></a></h2>
			<p>
				<em style='color: var(--main-bg-color); font-weight: bold;'><?php echo $data['type']; ?></em> - <em>Par
					<?php
						$autor = getAutor(strip_tags($data['auteur_topic']));
						echo $autor['firstname'];
					?></em>
			</p>
			<p>
				<?php
					$message = getMissive(strip_tags($data['ID_FORUM']));
					echo $message['message'];
				?>
			</p>
		</div>
	</div>
	<div class='gradient'></div>
	<div class='bottom_bar'>
		<ul>
			<li><?php echo $data['nb_vues']; ?> vues</li>
			<li><?php echo $data['nb_followers']; ?> followers</li>
			<li>Modifié le <?php echo $data['activite']; ?></li>
		</ul>
	</div>
</div>

<?php }

$answers->closeCursor();
?>

<?php include('../goodies/footer.php'); ?>

<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src='anim.js' type='text/javascript'></script>

</body>
</html>