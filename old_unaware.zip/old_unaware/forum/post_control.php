<?php

// Système de paginage;
if (! isset($_GET['page']))
{
	$page = 1;
}
elseif ($_GET['page'] > 0)
{
	$page = strip_tags($_GET['page']);
}

// On charge la page;
require('post_model.php');
$answers = getPost($page);
require('post_view.php');