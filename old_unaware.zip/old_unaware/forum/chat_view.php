<!DOCTYPE html>
<html>
<head>
	<meta charset='utf-8' />
	<title>Unaware - Secteurs d'activité</title>
	<link href='../color/color_purple.css' rel='stylesheet' />
	<link href='../goodies/style_dock.css' rel='stylesheet' />
	<link href='forum_sheet.css' rel='stylesheet' />
	<?php if (isset($_SESSION['no_js'])) { echo "<link href='../style_noJs.css' rel='stylesheet' />"; } ?>
</head>

<!-- On crée notre dock -->
<?php include('../goodies/dock.php'); ?>
<?php addViewOnPost(strip_tags($_GET['threat'])); ?>

<body>

	<div class='bannière' style='background-image: url("../pictures/castle_of_glass.png");'></div>

	<div class='first_block'>
		<img src='../pictures/session_icons/blue_gamepad.png' alt='Logo membre' />
		<div>
			<h1><?= $threat['titre']; ?></h1>
			<h4>By <a href='../profiles/profile_control.php?target=<?= $pseudo_autor; ?>'><?= $pseudo_autor; ?></a> in <a href='post_control.php?type=<?= $threat['type']; ?>'><?= $threat['type']; ?></a> Posted <?= $threat['activite']; ?> <?= $threat['nb_messages']; ?> Comments</h4>
		</div>
	</div>
		
	<!-- On crée le corp de notre site -->
	<div class='navigateur'>
		<p>
			<a href='../index.php'>Acceuil</a> >
			<a href='post_control.php'>forum</a> >
			<a href='post_control.php?type=<?= $threat["type"]; ?>'><?= $threat['type']; ?></a> >
			<?= $threat['titre']; ?>
		</p>
	</div>

	<div class='liens'>
		<ul>
			<li><a href='post_control.php'>Liste des forums</a></li>
			<li><a href='#'>Mes interventions</a></li>
			<li><a href='#'>Sujets suivis</a></li>
		</ul>
	</div>

	<div class='body_show'>

		<!-- Affichage des messages -->
		<?php while ($chat = $chats->fetch())
		{ 
			$autor = getAutor($chat['auteur']);
		?>

			<div class='<?= showStatusMember($chat['auteur'], $threat['auteur_topic']); ?>'>

				<div class='title'>
					<img src='../pictures/session_icons/blue_gamepad.png' alt='Logo membre' />
					<h2><a href='#'><?=  $autor['firstname']; ?></a></h2>
				</div>

				<div class='message'>
					<p><?= $chat['message']; ?></p>
					<p class='date'><?= $chat['post_date']; ?></p>
				</div>

			</div>

		<?php }
		$chats->closeCursor();
		?>
	</div>

	<!-- Zone de texte pour rédiger un commentaire -->
	<div class='ecrire'>
		<h1>Leave a reply !</h1>
		<?php if (! isset($_SESSION['pseudo'])) { echo "<p><em>Il faut être connecté pour poster des commentaires.</em></p>"; } ?>

		<form action='chat_control.php?threat=<?= $_GET['threat']; ?>' method='POST'>
			<textarea name='send_message' placeholder='Vous souhaitez partager quelque chose ?' required></textarea>

			<?php if (! isset($_SESSION['pseudo'])) { ?>
				<a href='../members/connection.php'>Se connecter</a>
			<?php } else { ?>
				<input type='submit' value='Envoyer' class='submit' />
			<?php } ?>
		</form>
	</div>

	<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
	<script src='anim.js' type='text/javascript'></script>

</body>
</html>