<?php

function getPost()
{
	// Connection to db;
	$db = dbConnect();

	// We're trying to get chats that user was selected.
	// If nothing selected, show all;

	if (isset($_GET['type']))
	{
		$type = strip_tags($_GET['type']);
		$answers = $db->prepare('SELECT * FROM forum WHERE type = :type ORDER BY activite DESC');
		$answers->execute(array(
			'type' => $type));
	}
	else
	{
		$answers = $db->query('SELECT * FROM forum ORDER BY activite DESC');
	}

	// Return answers;
	return $answers;
}


function getThreat()
{
	// Connection to db;
	$db = dbConnect();

	// We're trying to get the threat that user was selected.
	// If nothing selected, show all;

	if (isset($_GET['threat']))
	{
		$threat = strip_tags($_GET['threat']);
		$request = $db->prepare('SELECT * FROM forum WHERE ID_FORUM = :threat');
		$request->execute(array(
			'threat' => $threat));
	}
	else
	{
		throw new Exception('La variable threat a été retirée de l\'url');
	}

	$threat = $request->fetch();

	// Return answers;
	return $threat;
}

function getAutor($autor)
{					
	// We're trying to get autor topic.
	// Connection to db;
	$db = dbConnect();

	$request = $db->prepare('SELECT * FROM members WHERE id = :id_membre');
	$request->execute(array(
		'id_membre' => $autor));

	$autor = $request->fetch();

	// Return autor;
	return $autor;
}


function getMissive($ID_forum)
{
	// Connection to db;
	$db = dbConnect();

	// We're trying to get the first chat of the topic.
	$request = $db->prepare('SELECT * FROM messages WHERE ID_FORUM = :ID_forum');
	$request->execute(array(
		'ID_forum' => $ID_forum));

	$message = $request->fetch();

	// Return message;
	return $message;
}

function getChat($threat)
{
	// Connection to db;
	$db = dbConnect();

	// Trying to get 50's last chats;
	$chats = $db->prepare('SELECT * FROM messages WHERE ID_FORUM = :threat ORDER BY ID_MSG');
	$chats->execute(array(
		'threat' => $threat));

	// Return chats;
	return $chats;
}

function showStatusMember($ID_autor, $ID_getAutor)
{
	if ($ID_autor == $ID_getAutor)
	{
		$show = "autor";
	}
	else
	{
		$show = "member";
	}

	echo $show;
}

function postComment($postId, $author, $comment)
{
    $db = dbConnect();
    $comments = $db->prepare('INSERT INTO messages(ID_FORUM, message, auteur, post_date) VALUES(:forum, :message, :auteur, NOW())');
    $affectedLines = $comments->execute(array('forum' => $postId, 'message' => $comment, 'auteur' => $author));

    return $affectedLines;
}

function addViewOnPost($id_forum)
{
    $db = dbConnect();
    $posts = $db->prepare('UPDATE forum SET activite = NOW(), nb_messages = nb_messages + 1 WHERE ID_FORUM = :id_forum');
    $posts->execute(array('id_forum' => $id_forum));
}

function addComment($postId, $author, $comment)
{
    $affectedLines = postComment($postId, $author, $comment);

    if ($affectedLines === false) {
        echo 'post=' . $postId . 'autor=' .  $author . 'comment=' . $comment;
    }
    else {
        header('Location: chat_control.php?threat=' . $postId);
    }
}

function dbConnect()
{
	// Connection to db;
	try
    {
		$db = new PDO('mysql:host=localhost;dbname=unaware;charset=utf8', 'root', '');
        return $db;
    }
    catch(Exception $e)
    {
        die('Erreur : '.$e->getMessage());
    }

}