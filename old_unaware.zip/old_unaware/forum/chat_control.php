<?php

// On vérifie que les données transmises par l'url n'ont pas été retirées;
if (! isset($_GET['threat']))
{
	header('Location: ../index.php');
}
elseif (isset($_GET['threat']) AND $_GET['threat'] > 0)
{
	$threat = strip_tags($_GET['threat']);
}

require('post_model.php');

// On test si un commentaire à été envoyé;
if (isset($_POST['send_message']))
{
	session_start();
	$send_msg = strip_tags($_POST['send_message']);
	$id = strip_tags($_SESSION['id']);
	addComment($threat, $id, $send_msg);
}
else
{
	$chats = getChat($threat);
	$threat = getThreat();
	$pseudo_autor = getAutor($threat['auteur_topic'])['pseudo'];
	require('chat_view.php');
}