<?php
// On démarre les sessions;
session_start();

if (! isset($_SESSION['pseudo'])) { ?>
<header>
	<ul>
		<li><img src='../pictures/session_icons/anonymous.png' alt='logo membre' /></li>
		<li><a href='../index.php' class='unaware'>Unaware</a></li>
		<li><?php include('date.php'); ?> </li>
		<li id='alea'><a href='../index.php'>Javascript est désactivé ? Cliquez ici.</a></li>

		<div class='button'>
			<?php if ($_SERVER['PHP_SELF'] != "/index.php") { ?>
				<li id='inscript'><a href='../index.php?post' class='inscript'>S'inscrire</a></li>
			<?php } else { ?>
				<li id='inscript'><a href='#' class='inscript'>S'inscrire</a></li>
			<?php } ?>
			<li id='connect'><a class='connect' href='../members/connection.php'>Se connecter</a></li>
			<li class='dropdown'>
				<a href='#menu' class='menu'><img src='../pictures/main_icon_purple.png' alt='Logo du menu' /></a>
				<div id='options_menu'>
					<img src='../pictures/dropdown_top.png' />
					<a href='#'>Mon profil</a>
					<a href='#'>Mes conversations</a>
					<a href='#' id='separator' class='dev_post'>Types d'études</a>
					<?php if ($_SERVER['PHP_SELF'] != "/index.php") { ?>
						<a href='../index.php?post' class='inscript'>S'inscrire</a>
					<?php } else { ?>
						<a href='#' class='inscript'>S'inscrire</a>
					<?php } ?>
					<a href='../members/connection.php'>Se connecter</a>
				</div>
			</li>
		</div>
	</ul>
</header>

<?php } else { ?>
<header>
	<ul>
		<div class='block1'>
			<li><a href='../index.php' class='unaware' style="font-size: 1.65em; margin-right: 20px;">Unaware</a></li>
			<li><a href='#'>Mon profil</a></li>
			<li><a href='#'>Mes conversations</a></li>
			<li><a href='../forum/post_control.php'>Les conversations</a></li>
		</div>
		<!-- <li id='alea'><a href='no_javascript.php'>Javascript est désactivé ? Cliquez ici.</a></li> -->

		<div class='button'>
			<?php if ($_SERVER['PHP_SELF'] == "/forum/post_control.php") { ?>
				<li><img src='../pictures/research.png' class='research' /></li>
			<?php } else { ?>
				<li><?php include('date.php'); ?></li>
			<?php } ?>
			<li class='dropdown'>
				<img class='menu' src='../pictures/session_icons/green_gamepad.png' alt='Logo membre' style="cursor: pointer; border-radius: 500px;" />

				<div id='options_menu'>
					<img src='../pictures/dropdown_top.png' />
					<a href='#'>Mon profil</a>
					<a href='#'>Mes conversations</a>
					<a href='#' id='separator' class='dev_areas'>Types d'études</a>
					<a href='#' class='inscript'>Bonjour <?php echo $_SESSION['pseudo']; ?> !</a>
					<a href='../members/disconnection.php'>Se déconnecter</a>
				</div>

			</li>
		</div>
	</ul>
</header>

<?php } ?>