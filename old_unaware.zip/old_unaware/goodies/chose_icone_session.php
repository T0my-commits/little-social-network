<?php

// On choisi l'icone de session du membre.
// On commence par se connecter à la base de données;
$base_de_donnees_fct_chose = new PDO('mysql:host=localhost;dbname=unaware;charset=utf8', 'root', '');

// On cherche à récupérer la valeur du champ icone_session dans la table membre;
// On admet que le membre est connecté.
$reponse = $base_de_donnees_fct_chose->prepare('SELECT * FROM membres WHERE pseudo = :pseudo');
$reponse->execute(array(
	'pseudo' => $_SESSION['pseudo'])); // Se référer au pseudo ou a l'id ?...

$donnee = $reponse->fetch();

switch ($donnee['icone_session']) {
	case '"logo_anonyme"':
		$icone = 'logo_anonyme.png';
		break;
	
	case '"Manette violette"':
		$icone = 'Manette1_violette.png';
		break;

	default:
		$icone = 'logo_anonyme.png';
		break;

// On ferme le curseur;
$reponse->closeCursor();

// On vérifie notre emplacement et on retourne l'icone du membre;
if ($_SERVER['PHP_SELF'] == '/index.php')
{
	$path =  "src='images/icones_session/" . $icone . "'";
	echo $path;
}
else
{
	$path =  "src='../images/icones_session/" . $icone . "'";
	echo $path;
}

}