<style>
	.footer
	{
		width: 100%;
	}

	/* ------------------------------ Contacts -------------------------------- */
	#contact
	{
		font-family: 'montserratregular';
		display: flex;
		justify-content: space-around;
		align-items: center;
		align-self: center;
		flex-direction: column;
		height: 100px;
		color: white;
		background-color: var(--footer-bg-color);
		text-align: center;
		font-size: 21px;
		padding: 20px 20px;
		word-spacing: normal;
	}

	#contact p:nth-child(2)
	{
		font-size: 0.7em;
		padding: 10px 15px;
		border-radius: 5px;
		border: 1px solid white;
		text-transform: uppercase;
		transition: background-color 0.2s;
		cursor: pointer;
	}

	#contact p:nth-child(2):hover
	{
		background-color: rgba(255, 255, 255, 0.2);
		transition: background-color 0.2s;
	}

	/* ------------------------------ Footer ---------------------------------- */
	footer
	{
		text-align: center;
		font-size: 0.85em;
	}

</style>

<div class='footer'>
	<div id='contact'>
		<!-- En apprendre plus sur moi (corps du site) -->
		<p>Vous avez une remarque ? N'hésitez pas à me contacter.</p>
		<p><a>Me contacter</a></p>
	</div>

	<footer>
		<!-- Pied de page -->
		<p title='Thomas Devienne, beau garçon de 18 ans et concepteur de Unaware ;)'><em>Powered by T0my ~ :)</em></p>
	</footer>
</div>